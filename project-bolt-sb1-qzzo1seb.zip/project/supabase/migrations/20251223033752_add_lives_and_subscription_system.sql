/*
  # Add Lives and Subscription System

  1. New Tables
    - `user_lives`
      - `user_id` (uuid, references auth.users)
      - `lives` (integer) - Current lives count
      - `max_lives` (integer) - Maximum lives per day
      - `last_reset_at` (timestamptz) - Last time lives were reset
      - `infinite_mode` (boolean) - Whether infinite lives are enabled
      - `infinite_expires_at` (timestamptz) - When infinite mode expires
    
    - `subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `status` (text) - active, cancelled, expired
      - `plan_type` (text) - basic, premium
      - `created_at` (timestamptz)
      - `expires_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
*/

-- User lives table
CREATE TABLE IF NOT EXISTS user_lives (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  lives integer DEFAULT 5,
  max_lives integer DEFAULT 5,
  last_reset_at timestamptz DEFAULT now(),
  infinite_mode boolean DEFAULT false,
  infinite_expires_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_lives ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own lives"
  ON user_lives FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own lives"
  ON user_lives FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert own lives"
  ON user_lives FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  status text DEFAULT 'active',
  plan_type text NOT NULL,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz,
  stripe_session_id text,
  UNIQUE(user_id, plan_type)
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_user_lives_user_id ON user_lives(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON subscriptions(status);