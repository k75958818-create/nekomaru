import { useState } from 'react';
import { supabase, Language } from '../lib/supabase';
import { ArrowLeft, Trophy, Target } from 'lucide-react';

interface LevelTestProps {
  language: Language;
  onBack: () => void;
  onComplete: () => void;
}

const testQuestions = [
  {
    question: "Select the correct greeting:",
    options: ["Hello", "Goodbye", "Thanks", "Sorry"],
    correct: "Hello",
    difficulty: "beginner"
  },
  {
    question: "What is the plural form?",
    options: ["books", "book", "booking", "booked"],
    correct: "books",
    difficulty: "beginner"
  },
  {
    question: "Choose the correct verb tense:",
    options: ["went", "go", "going", "goes"],
    correct: "went",
    difficulty: "intermediate"
  },
  {
    question: "Which sentence is grammatically correct?",
    options: [
      "She don't like it",
      "She doesn't likes it",
      "She doesn't like it",
      "She not like it"
    ],
    correct: "She doesn't like it",
    difficulty: "intermediate"
  },
  {
    question: "Identify the conditional sentence:",
    options: [
      "I am happy",
      "If I were rich, I would travel",
      "She likes coffee",
      "They went home"
    ],
    correct: "If I were rich, I would travel",
    difficulty: "advanced"
  }
];

export default function LevelTest({ language, onBack, onComplete }: LevelTestProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [showCompletion, setShowCompletion] = useState(false);

  const handleAnswer = (answer: string) => {
    if (showResult) return;
    setSelectedAnswer(answer);
    setShowResult(true);

    if (answer === testQuestions[currentQuestion].correct) {
      setScore(score + 1);
    }
  };

  const handleNext = async () => {
    if (currentQuestion < testQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      const finalScore = score + (selectedAnswer === testQuestions[currentQuestion].correct ? 1 : 0);
      let level = 'beginner';

      if (finalScore >= 4) level = 'advanced';
      else if (finalScore >= 2) level = 'intermediate';

      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await supabase
          .from('user_language_levels')
          .upsert({
            user_id: user.id,
            language_id: language.id,
            level: level,
            test_score: finalScore
          }, {
            onConflict: 'user_id,language_id'
          });
      }

      setShowCompletion(true);
    }
  };

  if (showCompletion) {
    const finalScore = score + (selectedAnswer === testQuestions[currentQuestion].correct ? 1 : 0);
    let level = 'Beginner';
    let levelColor = '#16a34a';

    if (finalScore >= 4) {
      level = 'Advanced';
      levelColor = '#dc2626';
    } else if (finalScore >= 2) {
      level = 'Intermediate';
      levelColor = '#eab308';
    }

    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center shadow-xl max-w-md">
          <Trophy className="w-20 h-20 mx-auto mb-4" style={{ color: levelColor }} />
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
            Test Complete!
          </h2>
          <div className="text-xl font-semibold mb-4" style={{ color: levelColor }}>
            Your Level: {level}
          </div>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            You answered {finalScore} out of {testQuestions.length} questions correctly
          </p>
          <button
            onClick={onComplete}
            className="w-full py-4 rounded-xl font-medium text-white transition-all hover:shadow-lg"
            style={{ backgroundColor: language.theme_color }}
          >
            Start Learning
          </button>
        </div>
      </div>
    );
  }

  const question = testQuestions[currentQuestion];
  const progress = ((currentQuestion + 1) / testQuestions.length) * 100;

  return (
    <div className="min-h-screen" style={{
      background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
    }}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="p-2 rounded-lg hover:bg-white dark:hover:bg-gray-800 transition-all"
            >
              <ArrowLeft className="w-6 h-6" style={{ color: language.theme_color }} />
            </button>
            <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
              Question {currentQuestion + 1} of {testQuestions.length}
            </div>
          </div>

          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
            <div
              className="h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%`, backgroundColor: language.theme_color }}
            />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-xl mb-6">
          <div className="flex items-start gap-4 mb-6">
            <Target className="w-12 h-12" style={{ color: language.theme_color }} />
            <div className="flex-1">
              <div className="text-sm font-medium mb-2" style={{ color: language.theme_color }}>
                Level Assessment
              </div>
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                {question.question}
              </h2>
            </div>
          </div>

          <div className="space-y-3">
            {question.options.map((option, index) => {
              const isSelected = selectedAnswer === option;
              const isCorrect = option === question.correct;
              const showCorrect = showResult && isCorrect;
              const showWrong = showResult && isSelected && !isCorrect;

              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(option)}
                  disabled={showResult}
                  className={`w-full p-4 rounded-xl text-left font-medium transition-all transform hover:scale-[1.02] ${
                    showCorrect
                      ? 'bg-green-100 border-2 border-green-500 dark:bg-green-900'
                      : showWrong
                      ? 'bg-red-100 border-2 border-red-500 dark:bg-red-900'
                      : isSelected
                      ? 'border-2 dark:bg-gray-700'
                      : 'bg-gray-50 border-2 border-transparent hover:border-gray-300 dark:bg-gray-700'
                  }`}
                  style={
                    isSelected && !showResult
                      ? { borderColor: language.theme_color }
                      : {}
                  }
                >
                  <span className="text-gray-800 dark:text-white">{option}</span>
                </button>
              );
            })}
          </div>
        </div>

        {showResult && (
          <button
            onClick={handleNext}
            className="w-full py-4 rounded-xl font-bold text-white text-lg transition-all hover:shadow-lg transform hover:scale-[1.02]"
            style={{ backgroundColor: language.theme_color }}
          >
            {currentQuestion < testQuestions.length - 1 ? 'Next Question' : 'See Results'}
          </button>
        )}
      </div>
    </div>
  );
}
