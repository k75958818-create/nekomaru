import { useState } from 'react';
import { useLives } from '../contexts/LivesContext';
import { Zap, Clock, Infinity, Check } from 'lucide-react';

export default function Premium() {
  const { lives, hasInfiniteLives, infiniteExpiresAt, activateInfiniteLives } = useLives();
  const [loading, setLoading] = useState(false);

  const handlePurchase = async (planType: string) => {
    setLoading(true);
    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ planType }),
      });

      const data = await response.json();

      if (data.url) {
        window.location.href = data.url;
      }
    } catch (error) {
      console.error('Payment error:', error);
      alert('Payment processing failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const daysRemaining = infiniteExpiresAt
    ? Math.ceil((new Date(infiniteExpiresAt).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-yellow-500" />
            <h3 className="text-xl font-bold text-gray-800 dark:text-white">
              Current Lives
            </h3>
          </div>
          <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {hasInfiniteLives ? '∞' : lives}
          </div>
        </div>

        {hasInfiniteLives && (
          <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900 dark:bg-opacity-30 border border-blue-200 dark:border-blue-700">
            <p className="text-sm text-blue-700 dark:text-blue-300 font-medium">
              Infinite Lives Active
            </p>
            {daysRemaining > 0 && (
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                Expires in {daysRemaining} days
              </p>
            )}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg border-2 border-gray-200 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-400 transition-all">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="w-5 h-5 text-green-500" />
            <h3 className="font-bold text-gray-800 dark:text-white">7 Days</h3>
          </div>
          <div className="mb-4">
            <div className="text-3xl font-bold text-gray-800 dark:text-white">$2.99</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">7 days of infinite lives</p>
          </div>
          <ul className="space-y-2 mb-6 text-sm text-gray-700 dark:text-gray-300">
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Unlimited lives
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              All lessons unlocked
            </li>
          </ul>
          <button
            onClick={() => handlePurchase('7days')}
            disabled={loading}
            className="w-full py-3 rounded-xl bg-green-500 hover:bg-green-600 text-white font-medium transition-all transform hover:scale-[1.02] disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Get 7 Days'}
          </button>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900 dark:to-purple-900 rounded-2xl p-6 shadow-lg border-2 border-blue-500 dark:border-purple-500 relative overflow-hidden">
          <div className="absolute -top-4 -right-4 bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-xs font-bold rotate-12">
            BEST VALUE
          </div>
          <div className="flex items-center gap-2 mb-4">
            <Infinity className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            <h3 className="font-bold text-gray-800 dark:text-white">30 Days</h3>
          </div>
          <div className="mb-4">
            <div className="text-3xl font-bold text-gray-800 dark:text-white">$7.99</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Full month of infinite lives</p>
          </div>
          <ul className="space-y-2 mb-6 text-sm text-gray-700 dark:text-gray-300">
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Unlimited lives
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              All lessons unlocked
            </li>
            <li className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              No ads
            </li>
          </ul>
          <button
            onClick={() => handlePurchase('30days')}
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium transition-all transform hover:scale-[1.02] disabled:opacity-50"
          >
            {loading ? 'Processing...' : 'Get 30 Days'}
          </button>
        </div>
      </div>
    </div>
  );
}
