import { useEffect, useState } from 'react';
import { supabase, Language, Lesson, Question } from '../lib/supabase';
import { ArrowLeft, CheckCircle, XCircle, Trophy, Zap, Heart } from 'lucide-react';
import { useLives } from '../contexts/LivesContext';

interface LessonViewProps {
  language: Language;
  lesson: Lesson;
  onBack: () => void;
  onComplete: () => void;
}

export default function LessonView({ language, lesson, onBack, onComplete }: LessonViewProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<boolean[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCompletion, setShowCompletion] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const { lives, hasInfiniteLives, useLive } = useLives();

  useEffect(() => {
    loadQuestions();
  }, [lesson.id]);

  const loadQuestions = async () => {
    const { data } = await supabase
      .from('questions')
      .select('*')
      .eq('lesson_id', lesson.id)
      .order('question_number');

    if (data && data.length > 0) {
      setQuestions(data);
    }
    setLoading(false);
  };

  const handleAnswer = async (answer: string) => {
    if (showResult) return;

    const canContinue = await useLive();
    if (!canContinue && !hasInfiniteLives) {
      setShowGameOver(true);
      return;
    }

    setSelectedAnswer(answer);
    setShowResult(true);

    const isCorrect = answer === questions[currentQuestion].correct_answer;
    setAnswers([...answers, isCorrect]);

    if (isCorrect) {
      setScore(score + 1);
    }
  };

  const handleNext = async () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const finalScore = score + (selectedAnswer === questions[currentQuestion].correct_answer ? 1 : 0);
        await supabase
          .from('user_progress')
          .upsert({
            user_id: user.id,
            lesson_id: lesson.id,
            completed: true,
            score: finalScore,
            completed_at: new Date().toISOString()
          }, {
            onConflict: 'user_id,lesson_id'
          });
      }
      setShowCompletion(true);
    }
  };

  const getOptionLetter = (index: number) => ['A', 'B', 'C', 'D'][index];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{
          borderColor: `${language.theme_color} transparent transparent transparent`
        }}></div>
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center shadow-xl max-w-md">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
            No Questions Available
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            This lesson doesn't have questions yet. Please check back later!
          </p>
          <button
            onClick={onBack}
            className="px-6 py-3 rounded-xl font-medium text-white transition-all"
            style={{ backgroundColor: language.theme_color }}
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (showGameOver) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center shadow-xl max-w-md">
          <Heart className="w-20 h-20 mx-auto mb-4 text-red-500" />
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
            Out of Lives!
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            You've run out of lives. Get infinite lives to keep learning!
          </p>
          <div className="space-y-3">
            <button
              onClick={onComplete}
              className="w-full px-6 py-4 rounded-xl font-medium text-white transition-all hover:shadow-lg"
              style={{ backgroundColor: language.theme_color }}
            >
              Get Infinite Lives
            </button>
            <button
              onClick={onBack}
              className="w-full px-6 py-4 rounded-xl font-medium border-2 transition-all"
              style={{ borderColor: language.theme_color, color: language.theme_color }}
            >
              Back to Lessons
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (showCompletion) {
    const finalScore = score + (selectedAnswer === questions[currentQuestion].correct_answer ? 1 : 0);
    const percentage = (finalScore / questions.length) * 100;

    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 text-center shadow-xl max-w-md">
          <div className="mb-6">
            <Trophy className="w-20 h-20 mx-auto mb-4" style={{ color: language.theme_color }} />
            <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
              Lesson Complete!
            </h2>
            <div className="text-6xl font-bold mb-2" style={{ color: language.theme_color }}>
              {percentage.toFixed(0)}%
            </div>
            <p className="text-gray-600 dark:text-gray-400">
              {finalScore} out of {questions.length} correct
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={onComplete}
              className="w-full px-6 py-4 rounded-xl font-medium text-white transition-all hover:shadow-lg"
              style={{ backgroundColor: language.theme_color }}
            >
              Continue Learning
            </button>
            <button
              onClick={onBack}
              className="w-full px-6 py-4 rounded-xl font-medium border-2 transition-all"
              style={{ borderColor: language.theme_color, color: language.theme_color }}
            >
              Back to Lessons
            </button>
          </div>
        </div>
      </div>
    );
  }

  const question = questions[currentQuestion];
  const options = [
    { letter: 'A', text: question.option_a },
    { letter: 'B', text: question.option_b },
    { letter: 'C', text: question.option_c },
    { letter: 'D', text: question.option_d }
  ];

  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen" style={{
      background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
    }}>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={onBack}
              className="p-2 rounded-lg hover:bg-white dark:hover:bg-gray-800 transition-all"
            >
              <ArrowLeft className="w-6 h-6" style={{ color: language.theme_color }} />
            </button>
            <div className="flex items-center gap-4">
              <div className="text-sm font-medium text-gray-600 dark:text-gray-400">
                Question {currentQuestion + 1} of {questions.length}
              </div>
              <div className={`flex items-center gap-1 px-3 py-1 rounded-lg ${hasInfiniteLives ? 'bg-purple-100 dark:bg-purple-900' : 'bg-red-100 dark:bg-red-900'}`}>
                <Heart className={`w-4 h-4 ${hasInfiniteLives ? 'text-purple-600' : 'text-red-600'}`} />
                <span className={`text-sm font-bold ${hasInfiniteLives ? 'text-purple-600' : 'text-red-600'}`}>
                  {hasInfiniteLives ? '∞' : lives}
                </span>
              </div>
            </div>
          </div>

          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
            <div
              className="h-3 rounded-full transition-all duration-500"
              style={{ width: `${progress}%`, backgroundColor: language.theme_color }}
            />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-xl mb-6">
          <div className="flex items-start gap-4 mb-6">
            <div className="text-5xl">{lesson.animal_emoji}</div>
            <div className="flex-1">
              <div className="text-sm font-medium mb-2" style={{ color: language.theme_color }}>
                {lesson.animal} says:
              </div>
              <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
                {question.question_text}
              </h2>
            </div>
          </div>

          <div className="space-y-3">
            {options.map((option, index) => {
              const isSelected = selectedAnswer === option.letter;
              const isCorrect = option.letter === question.correct_answer;
              const showCorrect = showResult && isCorrect;
              const showWrong = showResult && isSelected && !isCorrect;

              return (
                <button
                  key={option.letter}
                  onClick={() => handleAnswer(option.letter)}
                  disabled={showResult}
                  className={`w-full p-4 rounded-xl text-left font-medium transition-all transform hover:scale-[1.02] ${
                    showCorrect
                      ? 'bg-green-100 border-2 border-green-500 dark:bg-green-900'
                      : showWrong
                      ? 'bg-red-100 border-2 border-red-500 dark:bg-red-900'
                      : isSelected
                      ? 'border-2 dark:bg-gray-700'
                      : 'bg-gray-50 border-2 border-transparent hover:border-gray-300 dark:bg-gray-700'
                  }`}
                  style={
                    isSelected && !showResult
                      ? { borderColor: language.theme_color }
                      : {}
                  }
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                        showCorrect
                          ? 'bg-green-500 text-white'
                          : showWrong
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-200 text-gray-700 dark:bg-gray-600 dark:text-gray-300'
                      }`}
                    >
                      {option.letter}
                    </div>
                    <span className="flex-1 text-gray-800 dark:text-white">{option.text}</span>
                    {showCorrect && <CheckCircle className="w-6 h-6 text-green-500" />}
                    {showWrong && <XCircle className="w-6 h-6 text-red-500" />}
                  </div>
                </button>
              );
            })}
          </div>

          {showResult && (
            <div className="mt-6 p-4 rounded-xl bg-blue-50 dark:bg-blue-900 dark:bg-opacity-30">
              <div className="flex items-start gap-2">
                <div className="text-4xl">{lesson.animal_emoji}</div>
                <div>
                  <div className="font-medium text-gray-800 dark:text-white mb-1">
                    {selectedAnswer === question.correct_answer ? 'Correct!' : 'Not quite right'}
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {question.explanation}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {showResult && (
          <button
            onClick={handleNext}
            className="w-full py-4 rounded-xl font-bold text-white text-lg transition-all hover:shadow-lg transform hover:scale-[1.02]"
            style={{ backgroundColor: language.theme_color }}
          >
            {currentQuestion < questions.length - 1 ? 'Next Question' : 'Complete Lesson'}
          </button>
        )}
      </div>
    </div>
  );
}
