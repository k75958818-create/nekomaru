import { useEffect, useState } from 'react';
import { supabase, Language, Lesson } from '../lib/supabase';
import { ArrowLeft, Lock, CheckCircle, Star, BookOpen, Zap } from 'lucide-react';
import { useLives } from '../contexts/LivesContext';

interface LessonListProps {
  language: Language;
  onSelectLesson: (lesson: Lesson) => void;
  onBack: () => void;
}

export default function LessonList({ language, onSelectLesson, onBack }: LessonListProps) {
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { lives, hasInfiniteLives } = useLives();

  useEffect(() => {
    loadLessons();
    loadProgress();
  }, [language.id]);

  const loadLessons = async () => {
    const { data } = await supabase
      .from('lessons')
      .select('*')
      .eq('language_id', language.id)
      .order('lesson_number')
      .limit(50);

    if (data) setLessons(data);
    setLoading(false);
  };

  const loadProgress = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from('user_progress')
      .select('lesson_id')
      .eq('user_id', user.id)
      .eq('completed', true);

    if (data) {
      setCompletedLessons(new Set(data.map(p => p.lesson_id)));
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300';
      case 'intermediate': return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900 dark:text-yellow-300';
      case 'advanced': return 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{
        background: `linear-gradient(135deg, ${language.theme_color}10, ${language.accent_color}10)`
      }}>
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-t-transparent" style={{
          borderColor: `${language.theme_color} transparent transparent transparent`
        }}></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen" style={{
      background: `linear-gradient(135deg, ${language.theme_color}08, ${language.accent_color}08)`
    }}>
      <div className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4 flex-1">
            <button
              onClick={onBack}
              className="p-3 rounded-xl bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-all"
            >
              <ArrowLeft className="w-6 h-6" style={{ color: language.theme_color }} />
            </button>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-4xl">{language.flag_emoji}</span>
                <h1 className="text-4xl font-bold text-gray-800 dark:text-white">
                  {language.name}
                </h1>
              </div>
              <p className="text-gray-600 dark:text-gray-400">
                {completedLessons.size} of {lessons.length} lessons completed
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white dark:bg-gray-800 shadow-lg">
            <Zap className={hasInfiniteLives ? 'text-purple-500' : 'text-yellow-500'} />
            <span className="font-bold text-gray-800 dark:text-white">
              {hasInfiniteLives ? '∞' : lives} lives
            </span>
          </div>
        </div>

        {lessons.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-12 text-center shadow-lg">
            <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
              Lessons Coming Soon
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              We're preparing amazing content for {language.name}. Check back soon!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {lessons.map((lesson, index) => {
              const isCompleted = completedLessons.has(lesson.id);
              const isLocked = index > 0 && !completedLessons.has(lessons[index - 1].id);

              return (
                <button
                  key={lesson.id}
                  onClick={() => !isLocked && onSelectLesson(lesson)}
                  disabled={isLocked}
                  className={`relative bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg transition-all duration-300 text-left ${
                    isLocked
                      ? 'opacity-50 cursor-not-allowed'
                      : 'hover:shadow-2xl transform hover:scale-[1.02] cursor-pointer'
                  }`}
                  style={{
                    borderLeft: `4px solid ${language.theme_color}`
                  }}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{lesson.animal_emoji}</span>
                      <div>
                        <div className="text-sm font-semibold" style={{ color: language.theme_color }}>
                          Lesson {lesson.lesson_number}
                        </div>
                        <h3 className="text-lg font-bold text-gray-800 dark:text-white">
                          {lesson.title}
                        </h3>
                      </div>
                    </div>
                    {isLocked && <Lock className="w-5 h-5 text-gray-400" />}
                    {isCompleted && <CheckCircle className="w-5 h-5 text-green-500" />}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-xs px-3 py-1 rounded-full font-medium ${getDifficultyColor(lesson.difficulty)}`}>
                      {lesson.difficulty}
                    </span>
                    <div className="flex items-center gap-1 text-yellow-500 text-sm">
                      <Star className="w-4 h-4 fill-current" />
                      <span className="font-medium">14 questions</span>
                    </div>
                  </div>

                  <div className="mt-3 text-sm text-gray-600 dark:text-gray-400">
                    {lesson.animal} will guide you
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
