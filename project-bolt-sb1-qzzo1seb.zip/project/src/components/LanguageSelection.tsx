import { useEffect, useState } from 'react';
import { supabase, Language } from '../lib/supabase';
import { Sparkles, Trophy, Settings } from 'lucide-react';

interface LanguageSelectionProps {
  onSelectLanguage: (language: Language) => void;
  onOpenSettings: () => void;
}

export default function LanguageSelection({ onSelectLanguage, onOpenSettings }: LanguageSelectionProps) {
  const [languages, setLanguages] = useState<Language[]>([]);
  const [progress, setProgress] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLanguages();
    loadProgress();
  }, []);

  const loadLanguages = async () => {
    const { data } = await supabase
      .from('languages')
      .select('*')
      .order('name');

    if (data) setLanguages(data);
    setLoading(false);
  };

  const loadProgress = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data: progressData } = await supabase
      .from('user_progress')
      .select('lesson_id, completed')
      .eq('user_id', user.id)
      .eq('completed', true);

    const { data: lessonsData } = await supabase
      .from('lessons')
      .select('id, language_id');

    if (progressData && lessonsData) {
      const progressByLanguage: Record<string, number> = {};

      lessonsData.forEach(lesson => {
        if (!progressByLanguage[lesson.language_id]) {
          progressByLanguage[lesson.language_id] = 0;
        }
      });

      progressData.forEach(p => {
        const lesson = lessonsData.find(l => l.id === p.lesson_id);
        if (lesson) {
          progressByLanguage[lesson.language_id]++;
        }
      });

      setProgress(progressByLanguage);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
              Choose Your Language
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Start your journey to fluency
            </p>
          </div>
          <button
            onClick={onOpenSettings}
            className="p-3 rounded-xl bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-all border border-gray-200 dark:border-gray-700"
          >
            <Settings className="w-6 h-6 text-gray-700 dark:text-gray-300" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {languages.map((language) => {
            const completedLessons = progress[language.id] || 0;
            const totalLessons = 500;
            const progressPercent = (completedLessons / totalLessons) * 100;

            return (
              <button
                key={language.id}
                onClick={() => onSelectLanguage(language)}
                className="group relative bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-opacity-50 overflow-hidden transform hover:scale-[1.02]"
                style={{
                  borderColor: `${language.theme_color}40`
                }}
              >
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                  style={{
                    background: `linear-gradient(135deg, ${language.theme_color}, ${language.accent_color})`
                  }}
                />

                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-4">
                    <div className="text-5xl">{language.flag_emoji}</div>
                    {completedLessons > 0 && (
                      <div className="flex items-center gap-1 text-yellow-500">
                        <Trophy className="w-4 h-4" />
                        <span className="text-sm font-semibold">{completedLessons}</span>
                      </div>
                    )}
                  </div>

                  <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
                    {language.name}
                  </h3>

                  {completedLessons > 0 ? (
                    <>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-2">
                        <div
                          className="h-2 rounded-full transition-all duration-500"
                          style={{
                            width: `${progressPercent}%`,
                            backgroundColor: language.theme_color
                          }}
                        />
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {completedLessons} of {totalLessons} lessons completed
                      </p>
                    </>
                  ) : (
                    <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                      <Sparkles className="w-4 h-4" style={{ color: language.theme_color }} />
                      <span>Start learning today</span>
                    </div>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
