import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

interface LivesContextType {
  lives: number;
  maxLives: number;
  hasInfiniteLives: boolean;
  infiniteExpiresAt: string | null;
  useLive: () => Promise<boolean>;
  restoreLives: () => Promise<void>;
  activateInfiniteLives: (durationDays: number) => Promise<void>;
}

const LivesContext = createContext<LivesContextType | undefined>(undefined);

export function LivesProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [lives, setLives] = useState(5);
  const [maxLives, setMaxLives] = useState(5);
  const [hasInfiniteLives, setHasInfiniteLives] = useState(false);
  const [infiniteExpiresAt, setInfiniteExpiresAt] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadLives();
      const interval = setInterval(checkInfiniteLivesExpiry, 60000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const loadLives = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_lives')
      .select('*')
      .eq('user_id', user.id)
      .maybeSingle();

    if (data) {
      setLives(data.lives);
      setMaxLives(data.max_lives);

      const infinite = data.infinite_mode && data.infinite_expires_at && new Date(data.infinite_expires_at) > new Date();
      setHasInfiniteLives(infinite);
      setInfiniteExpiresAt(data.infinite_expires_at);
    } else if (user) {
      await supabase
        .from('user_lives')
        .insert({
          user_id: user.id,
          lives: 5,
          max_lives: 5,
          infinite_mode: false
        });
      setLives(5);
      setMaxLives(5);
    }
  };

  const checkInfiniteLivesExpiry = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_lives')
      .select('infinite_mode, infinite_expires_at')
      .eq('user_id', user.id)
      .maybeSingle();

    if (data) {
      const infinite = data.infinite_mode && data.infinite_expires_at && new Date(data.infinite_expires_at) > new Date();
      setHasInfiniteLives(infinite);
      setInfiniteExpiresAt(data.infinite_expires_at);
    }
  };

  const useLive = async (): Promise<boolean> => {
    if (!user) return false;
    if (hasInfiniteLives) return true;
    if (lives <= 0) return false;

    const { error } = await supabase
      .from('user_lives')
      .update({ lives: lives - 1 })
      .eq('user_id', user.id);

    if (!error) {
      setLives(lives - 1);
      return true;
    }
    return false;
  };

  const restoreLives = async () => {
    if (!user) return;

    await supabase
      .from('user_lives')
      .update({ lives: maxLives })
      .eq('user_id', user.id);

    setLives(maxLives);
  };

  const activateInfiniteLives = async (durationDays: number) => {
    if (!user) return;

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + durationDays);

    await supabase
      .from('user_lives')
      .update({
        infinite_mode: true,
        infinite_expires_at: expiresAt.toISOString()
      })
      .eq('user_id', user.id);

    setHasInfiniteLives(true);
    setInfiniteExpiresAt(expiresAt.toISOString());
  };

  return (
    <LivesContext.Provider value={{ lives, maxLives, hasInfiniteLives, infiniteExpiresAt, useLive, restoreLives, activateInfiniteLives }}>
      {children}
    </LivesContext.Provider>
  );
}

export function useLives() {
  const context = useContext(LivesContext);
  if (context === undefined) {
    throw new Error('useLives must be used within a LivesProvider');
  }
  return context;
}
