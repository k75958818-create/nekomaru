import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Language {
  id: string;
  name: string;
  code: string;
  flag_emoji: string;
  theme_color: string;
  accent_color: string;
}

export interface Lesson {
  id: string;
  language_id: string;
  lesson_number: number;
  title: string;
  animal: string;
  animal_emoji: string;
  difficulty: string;
}

export interface Question {
  id: string;
  lesson_id: string;
  question_number: number;
  question_text: string;
  correct_answer: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  explanation: string;
}

export interface UserProfile {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  theme: string;
}

export interface UserProgress {
  id: string;
  user_id: string;
  lesson_id: string;
  completed: boolean;
  score: number;
  completed_at: string | null;
}
