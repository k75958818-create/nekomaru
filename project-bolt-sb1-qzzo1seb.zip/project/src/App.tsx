import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LivesProvider } from './contexts/LivesContext';
import LoginPage from './components/LoginPage';
import LanguageSelection from './components/LanguageSelection';
import LessonList from './components/LessonList';
import LessonView from './components/LessonView';
import Settings from './components/Settings';
import LevelTest from './components/LevelTest';
import { Language, Lesson } from './lib/supabase';

type View =
  | { type: 'languages' }
  | { type: 'lessons'; language: Language }
  | { type: 'lesson'; language: Language; lesson: Lesson }
  | { type: 'settings' }
  | { type: 'level-test'; language: Language };

function AppContent() {
  const { user, loading } = useAuth();
  const [view, setView] = useState<View>({ type: 'languages' });

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage />;
  }

  if (view.type === 'settings') {
    return <Settings onBack={() => setView({ type: 'languages' })} />;
  }

  if (view.type === 'level-test') {
    return (
      <LevelTest
        language={view.language}
        onBack={() => setView({ type: 'lessons', language: view.language })}
        onComplete={() => setView({ type: 'lessons', language: view.language })}
      />
    );
  }

  if (view.type === 'lesson') {
    return (
      <LessonView
        language={view.language}
        lesson={view.lesson}
        onBack={() => setView({ type: 'lessons', language: view.language })}
        onComplete={() => setView({ type: 'lessons', language: view.language })}
      />
    );
  }

  if (view.type === 'lessons') {
    return (
      <LessonList
        language={view.language}
        onSelectLesson={(lesson) => setView({ type: 'lesson', language: view.language, lesson })}
        onBack={() => setView({ type: 'languages' })}
      />
    );
  }

  return (
    <LanguageSelection
      onSelectLanguage={(language) => setView({ type: 'lessons', language })}
      onOpenSettings={() => setView({ type: 'settings' })}
    />
  );
}

function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <LivesProvider>
          <AppContent />
        </LivesProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}

export default App;
